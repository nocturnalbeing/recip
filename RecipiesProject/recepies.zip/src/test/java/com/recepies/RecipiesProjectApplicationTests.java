package com.recepies;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecipiesProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
