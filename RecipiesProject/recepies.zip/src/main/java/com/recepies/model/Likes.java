package com.recepies.model;

import lombok.Data;

@Data
public class Likes {

	private Long likedOnRecepie;
	private String  emailOfLikedUser;

}
